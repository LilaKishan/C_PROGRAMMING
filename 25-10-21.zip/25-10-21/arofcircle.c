#include <stdio.h>
void main()
{
    float r,area;
    printf("enter value of r");
    scanf("%f",&r);
    area=3.14*r*r;
    printf("Area of circle is=%f",area);
}
