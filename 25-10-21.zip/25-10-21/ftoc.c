#include<stdio.h>
void main()
{
   float f,c;
    printf("enter value of temprature in (*f)");
    scanf("%f",&f);
    c=(f-32)/1.8;
    printf("temprature in (*c) is=%f",c);
}
