#include<stdio.h>
#include<math.h>
void main()
{
	int a,b,ans;
	printf("enter number :\n");
	scanf("%d",&a);
	printf("enter number :\n");
	scanf("%d",&b);
	ans=pow(a,b);
	printf("answer is :%d\n",ans);
}