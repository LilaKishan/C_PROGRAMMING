#include<stdio.h>
void main()
{
	int a,b,c;
	printf("enter first number :\n");
	scanf("%d",&a);
	printf("enter second number :\n");
	scanf("%d",&b);
	printf("enter third number :\n");
	scanf("%d",&c);
	if(a>b)
	{
		if(a>c)
		{
			printf("first number will be maximum.\n");
		}
		else
		{
			printf("third number will be maximum.\n");
		}
	}
	else
	{
		printf("second will be maximum.\n");
	}
}