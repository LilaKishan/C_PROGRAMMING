#include<stdio.h>
void main()
{
	int a;
	printf("enter year :\n");
	scanf("%d",&a);
	if(a%4==0)
	{
		if (a%100==0)
		{
			if(a%400==0)
			{
				printf("enter year is leap year.\n");
			}
			else
			{
				printf("enter year is not leap year.\n");
			}
		}
		else
		{
			printf("enter year is leap year.\n");
		}
	}
	else
	{
		printf("enter year is not leap year.\n");
	}
}