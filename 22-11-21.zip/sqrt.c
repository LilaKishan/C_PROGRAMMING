#include<stdio.h>
#include<math.h>
void main()
{
	float a,ans;
	printf("enter no. :\n");
	scanf("%f",&a);
	ans=sqrt;
	printf("your answer :")
}