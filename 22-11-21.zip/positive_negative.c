#include<stdio.h>
void main()
{
	int a;
	printf("enter number :\n");
	scanf("%d",&a);
	if (a>0)
	{
		printf("enter number is positive.\n");
	}
	else
	{
		if(a=0)
		{
			printf("enter number is zero.\n");
		}
		else
		{
			printf("enter number is negative.\n");
		}
	}

}