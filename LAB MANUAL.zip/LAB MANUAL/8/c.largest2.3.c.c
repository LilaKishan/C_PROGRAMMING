#include<stdio.h>
void main()
{
    int a,b,c;
    printf("Enter the value of a,b and c\n");
    scanf("%d%d%d",&a,&b,&c);
    a>b
    ?
       (printf("greater numer is %d",a*c))
    :
        printf("greater number is %d",b*c);
}

