#include<stdio.h>
void main()
{
    int a,b;
    printf("Enter the value of a and b\n");
    scanf("%d%d",&a,&b);
    a>b
    ?
       (printf("greater numer is %d",a))
    :
        printf("greater number is %d",b);
}
