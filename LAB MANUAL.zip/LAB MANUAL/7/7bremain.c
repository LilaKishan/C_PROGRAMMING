#include<stdio.h>
void main()
{
    int n1,n2,n3,n4,n5,n6,n7,n8,n9,n10;
    printf("enter 10 numbers :");
    scanf("%d%d%d%d%d%d%d%d%d%d",&n1,&n2,&n3,&n4,&n5,&n6,&n7,&n8,&n9,&n10);

}
