#include<stdio.h>
void main()
{
    float a,b,avg;
    printf("enter valur of a : \n");
    scanf("%f",&a);
    printf("enter value of b: \n");
    scanf("%f",&b);
    avg=(a+b)/2;
    printf("average of two no.s is %f",avg);
}
