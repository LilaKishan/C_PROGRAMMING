#include<stdio.h>
void main()
{
    printf("Maruti nandan,\n");
    printf("3-new subhash nagar,\n");
    printf("kothariya main road,\n");
    printf("rajkot.");
}
