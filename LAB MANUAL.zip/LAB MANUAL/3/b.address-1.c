#include<stdio.h>
void main()
{
    printf("Maruti nandan,3-new subhash nagar,Kothariya main road,rajkot.");
}
