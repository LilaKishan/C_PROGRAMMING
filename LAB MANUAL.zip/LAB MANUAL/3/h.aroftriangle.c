#include<stdio.h>
void main()
{
    float b,h,area;
    printf("enter value of base");
    scanf("%f",&b);
    printf("enter value of height");
    scanf("%f",&h);
    area=0.5*b*h;
    printf("area of triangle is=%f",area);
}
