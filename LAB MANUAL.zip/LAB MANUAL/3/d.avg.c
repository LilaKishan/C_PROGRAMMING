#include<stdio.h>
void main()
{
    float a,b,avg;
    a=10,b=5;
    avg=(a+b)/2;
    printf("average of 5 and 10 is %f",avg);
}
