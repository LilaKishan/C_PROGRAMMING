#include<stdio.h>
void main()
{
    float a,b,c;
    printf("enter valur of a : \n");
    scanf("%f",&a);
    printf("enter value of b: \n");
    scanf("%f",&b);
    c=a+b;
    printf("adition of a and b is %f",c);
}
