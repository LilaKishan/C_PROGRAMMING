#include<stdio.h>
void main()
{
    int a,b,c;
    a=5,b=10;
    c=a+b;
    printf("addition of 5 and 10 is %d",c);
}
