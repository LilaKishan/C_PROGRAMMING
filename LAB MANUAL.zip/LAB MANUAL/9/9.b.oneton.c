#include<stdio.h>
void main()
{
	int i=1,n;
	printf("enter value :");
	scanf("%d",&n);
	while(i<=n)
	{
		printf("%d\n",i);
		i++;
	}
}