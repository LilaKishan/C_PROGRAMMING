#include<stdio.h>
void main()
{
    float f,c;
    printf("enter value of temprature in (*c)");
    scanf("%f",&c);
    f=1.8*c+32;
    printf("temprature in (*f) is=%f",f);
}
