#include<stdio.h>
void main()
{
    int a;
    printf("enter no. :");
    scanf("%d",&a);
    if(a>=0)
    {
        printf("enter value is positive.");
    }
    if(a<0)
    {
        printf("enter value is negative.");
    }
}
